#include <string.h>
#include <stdio.h>
#define MAXSIZE 500

int chop (char *line) {

  line[(strlen(line))-1] = '\0';

return (0);

}
