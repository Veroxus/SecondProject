#include <string.h>
#include <stdio.h>
#define MAXSIZE 500

int trim (char *trim) {
  return (0);
}
